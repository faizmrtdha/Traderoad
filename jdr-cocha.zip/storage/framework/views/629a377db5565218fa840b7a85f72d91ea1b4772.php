<div class="about container">
    <section>
        <h2>About Us</h2>
        <p id="tentang">
            Berdiri sebagai perusahaan international trading dengan melakukan
            banyak kegiatan ekspor impor,kemudian kami melakukan inovasi
            bekerjasama dengan perkebunan kelapa di seluruh wilayah Indonesia
            dan mengolah produk turunan kelapa yang bernilai untuk memenuhi
            kebutuhan individu dan bisnis.
        </p>
    </section>
    <div class="img-about">
        <div class="img-parent">
            
            <img src="img/product/about-us-1.jpg" alt="asdw" class="img-fluid img-child img-child-1" id="about-1" />
            <img src="img/product/about-us-3.jpg" alt="asdw" class="img-fluid img-child img-child-2" id="about-3" />
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\jdr-cocha\resources\views/partials/about.blade.php ENDPATH**/ ?>