<h2 class="text-center title-product">Our Product</h2>
<div class="swiper" id="swiper">
    <div class="swiper-wrapper">
        <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="swiper-slide" id="swiper">
            <img src="img/product/<?php echo e($u['thumbnail']); ?>" class="img-fluid rounded slide-image" alt="tentang" />
            <a href="/product/<?php echo e($u["slug"]); ?>" id="swiper" class="overlay">
                See Details
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="swiper-pagination"></div>
</div>



<?php /**PATH D:\xampp\htdocs\jdr-cocha\resources\views/partials/slider.blade.php ENDPATH**/ ?>