<div class="gambar">
      <div class="container">
        <h3 class="mt-5">Supplying across the globe</h3>
        <h1>
          The Leading Supplier<br />
          of Coconut Product
        </h1>
      </div>
    </div>
<?php /**PATH D:\xampp\htdocs\jdr-cocha\resources\views/partials/jumbotron.blade.php ENDPATH**/ ?>