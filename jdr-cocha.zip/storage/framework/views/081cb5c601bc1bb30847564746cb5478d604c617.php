<div class="container">
    <section class="d-grid justify-content-center">
        <h3>Questions?</h3>
        <span>Let’s Get In Touch</span>
    </section>
    <div class="row">
        <div class="col">
            <img src="/img/jdr.png" width="250px" class="" alt="" />
            <h4>PT. Jajar Dwi Raya</h4>
            <span>We also continue to update the information about the company
                through social media, for the latest information you can follow
                our social media.</span>
            <div class="social-media">
                <a href="" id="linkedin">
                    <i class="fab fa-linkedin-in me-3"></i>
                </a>
                <a id="wa" href="https://wa.me/+62822222222" target="_blank" rel="noreferrer">
                    <i class="fab fa-whatsapp me-3"></i>
                </a>
            </div>
        </div>
        <div class="col"></div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\jdr-cocha\resources\views/partials/footer.blade.php ENDPATH**/ ?>