<!DOCTYPE html>
<html lang="en" id="home">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="/css/style.css" rel="stylesheet" />
    <!-- OWL JS -->
    <link rel="stylesheet" href="css/swiper.css">
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <!-- font awesome -->
    <link href="css/all.min.css" rel="stylesheet" type="text/css" />

    <title>Cocha | <?php echo e($title); ?></title>
</head>

<body>
    <div class="navigasi">
        <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="jumbotron">
        <?php echo $__env->make('partials.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="about-us" id="about">
        <?php echo $__env->make('partials.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="keyfeature" id="feature">
        <?php echo $__env->make('partials.keyfeature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="slider" id="product">
        <?php echo $__env->make('partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="warehouse" id="warehouse">
        <?php echo $__env->make('partials.warehouse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="team" id="team">
        <?php echo $__env->make('partials.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="footer" id="contact">
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <footer>
        <div class="container">
            <span>© 2021 Cocha. All rights reserved</span>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.slim.js"
        integrity="sha256-HwWONEZrpuoh951cQD1ov2HUK5zA5DwJ1DNUXaM6FsY=" crossorigin="anonymous"></script>
    <!-- swiperJS -->
    <script src="js/swiper.js"></script>
    <script src="js/apps.js"></script>
    <script src="js/bootstrap.bundle.min.js">
    </script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\jdr-cocha\resources\views/layouts/main.blade.php ENDPATH**/ ?>