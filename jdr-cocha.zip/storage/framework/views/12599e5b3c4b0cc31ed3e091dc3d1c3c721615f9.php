<nav class="navbar navbar-expand-lg">
    <div class="container ps-0">
        <a class="navbar-brand p-0" href="/" id="a-logo">
            <img class="img-fluid" src="/img/jdrlogo.png" alt="logo" width="40px" height="40px" />
            <div class="vr"></div>
            <span class="mb-0">Cocha</span>
        </a>
        
    </div>
</nav>
<?php /**PATH D:\xampp\htdocs\jdr-cocha\resources\views/partials/navbar_product.blade.php ENDPATH**/ ?>