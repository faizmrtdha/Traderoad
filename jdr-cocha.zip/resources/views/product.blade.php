@extends('layouts.product')
