<div class="container">
    <h2>Our Teams</h2>
    <div class="foto-team">
        <div class="row">
            <div class="col t-1">
                <img src="img/123.jpg" class="rounded-circle" alt="" width="200px" height="200px" />
                <h4 id="nama">Viqri Al Huda</h4>
                <span id="jabatan">Chief Executing Officer</span>
                <a href="" id="linked">
                    <i class="fab fa-linkedin fa-lg" id="linkedin"></i>
                </a>
            </div>
            <div class="col t-1">
                <img src="https://cbsnews1.cbsistatic.com/hub/i/2018/11/06/0c1af1b8-155a-458e-b105-78f1e7344bf4/2018-11-06t054310z-1334124005-rc1be15a8050-rtrmadp-3-people-sexiest-man.jpg"
                    class="rounded-circle" alt="" width="200px" height="200px" />
                <h4 id="nama">Aprianda Idrus</h4>
                <span id="jabatan">Chief Operating Officer</span>
                <a href="" id="linked">
                    <i class="fab fa-linkedin fa-lg" id="linkedin"></i>
                </a>
            </div>
            <div class="col t-1">
                <img src="https://cbsnews1.cbsistatic.com/hub/i/2018/11/06/0c1af1b8-155a-458e-b105-78f1e7344bf4/2018-11-06t054310z-1334124005-rc1be15a8050-rtrmadp-3-people-sexiest-man.jpg"
                    class="rounded-circle" alt="" width="200px" height="200px" />
                <h4 id="nama">Pandhita Hamzah</h4>
                <span id="jabatan">Chief Technology Officer</span>
                <a href="" id="linked">
                    <i class="fab fa-linkedin fa-lg" id="linkedin"></i>
                </a>
            </div>
        </div>
    </div>
</div>
