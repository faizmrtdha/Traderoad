{{-- <div class="container"> --}}
<h2 class="text-center">Our Warehouse</h2>
<div class="foto-ware">
    <img src="img/wh1.jpg" alt="" class="img-fluid wh">
    <img src="img/wh2.jpg" alt="" class="img-fluid wh">
    <img src="img/wh3.jpg" alt="" class="img-fluid wh">
</div>
{{-- </div> --}}
